import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class Main {

    public static void main(String[] args) {

        System.out.println("Magazin services");
       Item balls = new Item("Ball",ItemCondition.NEW,200,1);
       Item balls2 = new Item("Ball2",ItemCondition.NEW,1,1);
       Item chair = new Item("Chair",ItemCondition.NEW,11,1);

       FulfillmentCenter warehouse = new FulfillmentCenter("werehouse1",1000);
       warehouse.addProduct(balls);
       warehouse.addProduct(balls);
       warehouse.addProduct(balls2);
       warehouse.addProduct(chair);
       warehouse.summary();

        warehouse.getProduct(balls2);
       warehouse.summary();
       Item temp = warehouse.search("Chair");
       temp.print();
    }
}
