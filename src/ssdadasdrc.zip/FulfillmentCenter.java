import java.util.ArrayList;
import java.util.List;

public class FulfillmentCenter {
    String magazinName;
    List<Item> items = new ArrayList<>();
    double maximumCapacity;// summary maximal weight capacity

    public FulfillmentCenter(String _magazinName, double _maximumCapacity) {
        magazinName = _magazinName;
        maximumCapacity = _maximumCapacity;
    }

    void addProduct(Item item) {
        //getting actual warehouse weight
        double actualWarehouseWeight = 0;
        for (Item itemElement : items) {
            actualWarehouseWeight = +itemElement.weight;
        }
        //if warehouse is full throw error
        if (item.weight + actualWarehouseWeight >= maximumCapacity) {
            throw new IllegalArgumentException("Warehouse is full!");
        } else {
            boolean finded = false;
            for (Item itemElement : items) {
                if (itemElement.name.equals(item.name)) {
                    finded = true;
                    itemElement.weight = item.weight + itemElement.weight;
                    itemElement.quantity = item.quantity + itemElement.quantity;
                }
            }
            if (finded == false) {
                items.add(item);
            }
        }
    }

    void getProduct(Item item) {
        boolean found = false;
        for (Item itemElement : items) {
            if (itemElement.name.equals(item.name)) {
                found = true;
                if (--itemElement.quantity <= 0) {
                    items.remove(itemElement);
                }
                itemElement.quantity = --itemElement.quantity;
            }
        }
        if (found == false) {
            throw new IllegalArgumentException("This item not exist in warehouse!");
        }
    }

    void removeProduct(Item item) {
        items.remove(item);
    }

    void summary() {
        for (Item itemElement : items) {
            itemElement.print();
        }
    }

    Item search(String name) {
        Item temp = new Item(name, ItemCondition.NEW, 1, 1);
        for (Item itemElement : items) {
            int a = itemElement.compareTo(temp);
            if (a == 0) return itemElement;
        }
        throw new IllegalArgumentException("Item not exist!");
    }
    List<Item> searchPartial(String name){
        List<Item> items = new ArrayList<>();
        return items;

    }



}
